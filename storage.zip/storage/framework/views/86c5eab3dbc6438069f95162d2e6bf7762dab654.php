<?php $__env->startSection('failDelete'); ?>
    <?php if(session()->has('failedAdminDeleting')): ?>
        <!-- Button trigger modal -->
        <div class="modal fade show" id="failedDeleting" tabindex="-1" role="dialog" 
        data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="slide-out-right"
        aria-labelledby="exampleModalCenterTitle" style="display: block;">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Importante!</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="javascript:document.getElementById('failedDeleting').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                </div>
                <div class="modal-body">
                Este usuario pertenece a la administración, no se puede borrar.
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="javascript:document.getElementById('failedDeleting').style.display='none'">Aceptar</button>
                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('okDelete'); ?>
    <?php if(session()->has('successDeleting')): ?>
        <!-- Button trigger modal -->
        <div class="modal fade show" id="successDeleting" tabindex="-1" role="dialog" 
        data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="slide-out-right"
        aria-labelledby="successDeletingTitle" style="display: block;">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Importante!</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="javascript:document.getElementById('successDeleting').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                </div>
                <div class="modal-body">
                Usuario borrado correctamente.
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="javascript:document.getElementById('successDeleting').style.display='none'">Aceptar</button>
                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('okEmployeeEdit'); ?>
    <?php if(session()->has('successEdit')): ?>
        <!-- Button trigger modal -->
        <div class="modal fade show" id="successEdit" tabindex="-1" role="dialog" 
        data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="slide-out-right"
        aria-labelledby="successEditTitle" style="display: block;">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">¡Mensaje!</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="javascript:document.getElementById('successEdit').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                </div>
                <div class="modal-body">
                Perfil modificado correctamente.
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="javascript:document.getElementById('successEdit').style.display='none'">Aceptar</button>
                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('okBusinessEdit'); ?>
    <?php if(session()->has('successEdit')): ?>
        <!-- Button trigger modal -->
        <div class="modal fade show" id="successEdit" tabindex="-1" role="dialog" 
        data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="slide-out-right"
        aria-labelledby="successEditTitle" style="display: block;">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">¡Mensaje!</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="javascript:document.getElementById('successEdit').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                </div>
                <div class="modal-body">
                Información del negocio modificada correctamente.
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="javascript:document.getElementById('successEdit').style.display='none'">Aceptar</button>
                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('employee_delete'); ?>
    <?php if(session()->has('success_employee_delete')): ?>
        <!-- Button trigger modal -->
        <div class="modal fade show" id="success_employee_delete" tabindex="-1" role="dialog" 
        data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="slide-out-right"
        aria-labelledby="success_employee_deleteTitle" style="display: block;">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">¡Mensaje!</h5>
                <button type="button" class="close" data-dismiss="modal" onclick="javascript:document.getElementById('success_employee_delete').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                </div>
                <div class="modal-body">
                Empleado borrado correctamente.
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="javascript:document.getElementById('success_employee_delete').style.display='none'">Aceptar</button>
                <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('okEmployeeEdit'); ?>
    <!-- Success dialog -->
    <?php if(session()->has('successEdit')): ?>
    <!-- Button trigger modal -->
    <div class="modal fade show" id="successEdit" tabindex="-1" role="dialog" 
    data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="fly-in-up"
    aria-labelledby="successEdit" style="display: block;">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">¡Mensaje!</h5>
            <button type="button" class="close" data-dismiss="modal" 
            onclick="javascript:document.getElementById('successEdit').style.display='none'" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            </div>
            <div class="modal-body">
            Empleado modificado correctamente.
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal" 
            onclick="javascript:document.getElementById('successEdit').style.display='none'">Aceptar</button>
            <!--<button type="button" class="btn btn-primary">Save changes</button>-->
            </div>
        </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/layouts/generaldialog.blade.php ENDPATH**/ ?>