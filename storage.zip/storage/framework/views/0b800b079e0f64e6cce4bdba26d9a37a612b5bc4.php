
<?php $__env->startSection('contenido'); ?>
<?php if(auth()->guard()->check()): ?>
<h2>Editar datos de Administrador</h2>
<form action="<?php echo e(route('administrador.update', $administrador->idAdministrador)); ?>" 
        method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div>
        <label for="cedula">Cedula:</label>
        <input type="number" name="cedula" class="form-control" value="<?php echo e($administrador->cedula); ?>">
    </div>
    <div>
        <label for="nombres">Nombres:</label>
        <input type="text" name="nombres" class="form-control" value="<?php echo e($administrador->nombres); ?>" />
    </div>
    <div>
        <label for="apellidos">Apellidos:</label>
        <input type="text" name="apellidos" class="form-control" value="<?php echo e($administrador->apellidos); ?>" />
    </div>
    <div>
        <label for="direccion">Direccion:</label>
        <input type="text" name="direccion" class="form-control" value="<?php echo e($administrador->direccion); ?>" />
    </div>
    <div>
        <label for="telefono">Telefono:</label>
        <input type="text" name="telefono" class="form-control" value="<?php echo e($administrador->telefono); ?>" />
    </div>
    <div>
        <label for="especialidad">Especialidad:</label>
        <input type="text" name="especialidad" class="form-control" value="<?php echo e($administrador->especialidad); ?>" />
    </div>
    <div>
        <label for="Foto">Foto</label>
        <img id="imgId" src="<?php echo e(asset('storage').'/'.$administrador->Foto); ?>" width="100px" alt="" />
        <input class="form-control" type="file" name="Foto" onchange="read(this)" />
    </div>
    <div>
        <input class="btn btn-success mt-2 form-control" type="submit" value="Aceptar" />
        <a class="btn btn-warning mt-1 form-control" href="<?php echo e(route('administrador.index')); ?>">Regresar</a>
    </div>
</form>
<script>
    function read(val) {
        const reader = new FileReader();
        reader.onload = (event) => {
            document.getElementById("imgId").src = event.target.result;
        }
        reader.readAsDataURL(val.files[0]);
    }
</script>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    
<?php endif; ?>
<?php $__env->stopSection(); ?>   

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/administrador/edit.blade.php ENDPATH**/ ?>