
<?php $__env->startSection('contenido'); ?>
    <h2>Modificación de curso</h2>
    <form action="<?php echo e(route('curso.update',$curso->idCursosRealizados)); ?>" 
        method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div>
        <label for="nombre">Nombre</label>
        <input type="text" name="nombre" value="<?php echo e($curso->nombre); ?>" class="form-control">
    </div>
    <div>
        <label for="lugar">Lugar</label>
        <input type="text" name="lugar" value="<?php echo e($curso->lugar); ?>" class="form-control">
    </div>
    <div>
        <label for="tiempo">Tiempo</label>
        <input type="text" name="tiempo" value="<?php echo e($curso->tiempo); ?>" class="form-control">
    </div>
    <div>
        <label for="modalidad">Modalidad</label>
        <select class="form-select" aria-label="Default select example" name="modalidad">
            <?php $__currentLoopData = array("presencial","semipresencial","online","otro"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($modalidad == $curso->modalidad): ?>
                    <option value="<?php echo e($modalidad); ?>" selected><?php echo e($modalidad); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($modalidad); ?>"><?php echo e($modalidad); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label for="fechaComienzo">Fecha Comienzo</label>
        <input type="date" name="fechaComienzo" value="<?php echo e($curso->fechaComienzo); ?>" class="form-control">
    </div>
    <div>
        <label for="fechaFin">Fecha Fin</label>
        <input type="date" name="fechaFin" value="<?php echo e($curso->fechaFin); ?>" class="form-control">
    </div>
    <div>
        <label for="firma">Firma</label>
        <input type="text" name="firma" value="<?php echo e($curso->firma); ?>" class="form-control">
    </div>
    <div>
        <label for="archivo">Archivo</label>
        <input type="file" name="archivo" value="<?php echo e($curso->archivo); ?>" class="form-control">
    </div>
        <input class="btn btn-success mt-2 form-control" type="submit" value="Modificar"/>
        <a class="btn btn-warning mt-1 form-control" href="<?php echo e(route('curso.index')); ?>">Regresar</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/curso/edit.blade.php ENDPATH**/ ?>