
<?php $__env->startSection('contenido'); ?>
<h2>Editar datos de Usuario</h2>
<form action="<?php echo e(route('user.update', $user->idUser)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div>
        <label for="name">Nombre</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
    </div>
    <div>
        <label for="username">Usuario</label>
        <input type="text" name="username" class="form-control" value="<?php echo e($user->username); ?>" />
    </div>
    <div>
        <label for="password">Clave/Nueva Clave</label>
        <input type="text" name="password" class="form-control" value="<?php echo e($user->password); ?>" />
    </div>
    <div>
        <label for="email">Correo</label>
        <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>" />
    </div>
    <div>
        <input class="btn btn-success mt-2 form-control" type="submit" value="Modificar"/>
        <a class="btn btn-warning mt-1 form-control" href="<?php echo e(route('user.index')); ?>">Regresar</a>
    </div>
</form>
<!-- Success dialog -->
<?php if(session()->has('success_edit')): ?>
<!-- Button trigger modal -->
<div class="modal fade show" id="successEdit" tabindex="-1" role="dialog" 
data-mdb-toggle="animation" data-mdb-animation-reset="true" data-mdb-animation="fly-in-up"
aria-labelledby="successEdit" style="display: block;">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLongTitle">¡Mensaje!</h5>
    <button type="button" class="close" data-dismiss="modal" onclick="javascript:document.getElementById('successEdit').style.display='none'" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
    </div>
    <div class="modal-body">
    Usuario modificado correctamente.
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="javascript:document.getElementById('successEdit').style.display='none'">Aceptar</button>
    <!--<button type="button" class="btn btn-primary">Save changes</button>-->
    </div>
</div>
</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/users/edit.blade.php ENDPATH**/ ?>