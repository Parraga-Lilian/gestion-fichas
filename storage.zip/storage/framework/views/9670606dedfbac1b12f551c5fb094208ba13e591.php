<?php $__env->startSection('content'); ?>
    <div class="bg-light p-5 rounded">
        <?php if(auth()->guard()->check()): ?>
            <h1>Dashboard</h1>
            <p class="lead">Solo usuarios autenticados pueden ver esta seccion.</p>
            <a class="btn btn-lg btn-primary" href="https://codeanddeploy.com" 
            role="button">Ir al sistema &raquo;</a>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <h1>Inicio</h1>
            <p class="lead">Inicio.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/home/index.blade.php ENDPATH**/ ?>