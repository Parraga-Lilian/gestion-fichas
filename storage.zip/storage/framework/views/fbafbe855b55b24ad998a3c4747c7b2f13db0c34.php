
<?php $__env->startSection('contenido'); ?>
<?php use App\Models\Empleado; ?>
<h2>Información del negocio</h2>
<?php if(auth()->guard()->check()): ?>
    <?php if(!is_null($negocio)): ?>
        <form action="<?php echo e(route('negocio.update', $negocio->idNegocio)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label for="ruc_asoc">RUC Asociado: </label>
                <input type="text" name="ruc_asoc" class="form-control" value="<?php echo e($negocio->ruc_asoc); ?>" />
            </div>
            <div>
                <label for="razon_social">Razon Social: </label>
                <input type="text" name="razon_social" class="form-control" value="<?php echo e($negocio->razon_social); ?>" />
            </div>
            <div>
                <label for="actividad">Actividad: </label>
                <input type="text" name="actividad" class="form-control" value="<?php echo e($negocio->actividad); ?>" />
            </div>      
            <div>
                <label for="n_empleados">Número de empleados activos: </label>
                <input type="text" name="n_empleados" class="form-control" value="<?php echo e(count(Empleado::where('estado','activo')->get()) ?? 0); ?>" readonly />
            </div>
            <div>
                <label for="correo">Correo: </label>
                <input type="text" name="correo" class="form-control" value="<?php echo e($negocio->correo); ?>" />
            </div>
            <div>
                <label for="direccion">Direccion/Ciudad: </label>
                <input type="text" name="direccion" class="form-control" value="<?php echo e($negocio->direccion); ?>" />
            </div>
            <div>
                <input class="btn btn-success mt-2 form-control" type="submit" value="Modificar"/>
            </div>        
        </form>
    <?php else: ?>
    <form action="<?php echo e(route('negocio.store')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <div>
            <label for="ruc_asoc">RUC Asociado: </label>
            <input type="text" name="ruc_asoc" class="form-control" value="" required />
        </div>
        <div>
            <label for="razon_social">Razon Social: </label>
            <input type="text" name="razon_social" class="form-control" value="" required />
        </div>
        <div>
            <label for="actividad">Actividad: </label>
            <input type="text" name="actividad" class="form-control" value="" required />
        </div>      
        <div>
            <label for="n_empleados">Número de empleados activos: </label>
            <input type="text" name="n_empleados" class="form-control" value="<?php echo e((count((array)Empleado::where('estado','activo')) - 1) ?? 0); ?>" readonly />
        </div>
        <div>
            <label for="correo">Correo: </label>
            <input type="email" name="correo" class="form-control" value="" required />
        </div>
        <div>
            <label for="direccion">Direccion/Ciudad: </label>
            <input type="text" name="direccion" class="form-control" value="" required />
        </div>
        <div>
            <input class="btn btn-success mt-2 form-control" type="submit" value="Aceptar"/>
        </div>        
    </form>
    <?php endif; ?>
    <script>
      const list = document.getElementsByTagName("LI")[4];
      list.className += "active";
    </script>
    <?php echo $__env->make('layouts.generaldialog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('okBusinessEdit'); ?>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/negocio/index.blade.php ENDPATH**/ ?>