
<?php $__env->startSection('contenido'); ?>
    <h2>Modificación de certificacion</h2>
    <form action="<?php echo e(route('certificacion.update',$certificacion->idCertificaciones)); ?>" 
        method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div>
        <label for="nombre">Nombre</label>
        <input type="text" name="nombre" value="<?php echo e($certificacion->nombre); ?>" class="form-control">
    </div>
    <div>
        <label for="institucion">Institucion</label>
        <input type="text" name="institucion" value="<?php echo e($certificacion->institucion); ?>" class="form-control">
    </div>
    <div>
        <label for="fechaComienzo">Fecha Comienzo</label>
        <input type="date" name="fechaComienzo" value="<?php echo e($certificacion->fechaComienzo); ?>" class="form-control">
    </div>
    <div>
        <label for="fechaFin">Fecha Fin</label>
        <input type="date" name="fechaFin" value="<?php echo e($certificacion->fechaFin); ?>" class="form-control">
    </div>
    <div>
        <label for="tipo">Tipo</label>
        <select class="form-select" aria-label="Default select example" name="tipo">
            <?php $__currentLoopData = array("diplomado","especializacion","reconocimiento",
            "participacion","asistencia","otro"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($tipo == $certificacion->tipo): ?>
                    <option value="<?php echo e($tipo); ?>" selected><?php echo e($tipo); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($tipo); ?>"><?php echo e($tipo); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label for="archivo">Archivo</label>
        <input type="file" name="archivo" class="form-control">
        <?php if($certificacion->archivo): ?>
            <p>Nombre de archivo actual: <?php echo e($certificacion->nombre); ?></p>
        <?php endif; ?>
    </div>
    
        <input class="btn btn-success mt-2 form-control" type="submit" value="Modificar"/>
        <a class="btn btn-warning mt-1 form-control" href="<?php echo e(route('certificacion.index')); ?>">Regresar</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/certificacion/edit.blade.php ENDPATH**/ ?>