<!DOCTYPE html>
<?php use App\Models\Administrador; ?>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" 
  integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>" />
</head>
<body>
    <div class="container px-4 py-5 mx-auto">
        <div class="card card0">
            <div class="d-flex flex-lg-row flex-column-reverse">
                <div class="card card1">
                    <div class="row justify-content-center my-auto">
                        <div class="col-md-8 col-10 my-5">
                            <div class="row justify-content-center px-3 mb-2">
                                <img id="logo" style="border-radius:50%;height:100px;width:120px;" src="<?php echo e(asset('imagenes/talento.png')); ?>" />
                                <h3 class="text-center heading">Sistema de perfiles</h3>
                                <h5 class="text-center heading">Ingrese sus datos: </h5>
                            </div>
                            <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form method="post" action="<?php echo e(route('register.perform')); ?>" >
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                                <div class="form-group form-floating mb-3">
                                    <label for="floatingEmail">Nombre:</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="" required="required" autofocus>
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group form-floating mb-3">
                                    <label for="floatingEmail">Correo electrónico:</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="" required="required" autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>
                        
                                <div class="form-group form-floating mb-3">
                                    <label for="floatingName">Nombre de usuario:</label>
                                    <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="" required="required" autofocus>
                                    <?php if($errors->has('username')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-group form-floating mb-3">
                                    <label for="floatingPassword">Contraseña:</label>
                                    <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="" required="required">
                                    <?php if($errors->has('password')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                                    <?php endif; ?>
                                </div>
                        
                                <div class="form-group form-floating mb-3">
                                    <label for="floatingConfirmPassword">Confirmar Contraseña:</label>
                                    <input type="password" class="form-control" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="" required="required">
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
                                    <?php endif; ?>
                                </div>
                        
                                <div class="form-group form-floating mb-3">
                                    <label for="floatingConfirmPassword">Tipo de usuario: </label>
                                    <select class="form-select" aria-label="Default select example" name="tipo">
                                        <?php if(Administrador::all()->isEmpty()): ?>
                                            <option value="administrador" selected>Administrador</option>
                                            <option value="empleado" >Empleado</option>
                                        <?php else: ?>
                                            <option value="empleado" selected>Empleado</option>
                                        <?php endif; ?>
                                        
                                    </select>
                                </div>
                               
                                <button class="w-100 btn btn-lg btn-primary" type="submit">Registrarse</button>
                                <div class="bottom text-center mb-2">
                                    <p class="sm-text mx-auto mb-3"><a class="btn btn-white ml-2" href="/login">Regresar.</a></p>
                                </div>
                                <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card card2">
                    <div class="my-auto mx-md-5 px-md-5 right">
                        <h3 class="text-white">Somos más que solo un programa</h3>
                        <small class="text-white">Permitimos a las personas centrarse más en su trabajo y 
                            dedicar menos tiempo en el registro de información que de otra forma 
                            sería complejo de almanacenar y gestionar en general.</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/auth/register.blade.php ENDPATH**/ ?>