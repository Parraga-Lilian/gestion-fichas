
<?php $__env->startSection('contenido'); ?>
<?php use App\Models\Empleado; ?>
<h2>Visualizar negocio</h2>
<?php if(auth()->guard()->check()): ?>
    <?php if(!is_null($negocio)): ?>
        <form>
            <?php echo csrf_field(); ?>
            <div>
                <label for="ruc_asoc">RUC Asociado: </label>
                <input type="text" name="ruc_asoc" class="form-control" value="<?php echo e($negocio->ruc_asoc); ?>" readonly />
            </div>
            <div>
                <label for="razon_social">Razon Social: </label>
                <input type="text" name="razon_social" class="form-control" value="<?php echo e($negocio->razon_social); ?>" readonly />
            </div>
            <div>
                <label for="actividad">Actividad: </label>
                <input type="text" name="actividad" class="form-control" value="<?php echo e($negocio->actividad); ?>" readonly />
            </div>      
            <div>
                <label for="n_empleados">Número de empleados activos: </label>
                <input type="text" name="n_empleados" class="form-control" value="<?php echo e(count(Empleado::where('estado','activo')->get()) ?? 0); ?>" readonly />
            </div>
            <div>
                <label for="correo">Correo: </label>
                <input type="text" name="correo" class="form-control" value="<?php echo e($negocio->correo); ?>" readonly />
            </div>
            <div>
                <label for="direccion">Direccion/Ciudad: </label>
                <input type="text" name="direccion" class="form-control" value="<?php echo e($negocio->direccion); ?>" readonly />
            </div>
        </form>
    <?php endif; ?>
    <script>
      const list = document.getElementsByTagName("LI")[4];
      list.className += "active";
    </script>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
    <h1>Homepage</h1>
    <p class="lead">Your viewing the home page. Please login to view the restricted data.</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/negocio/show.blade.php ENDPATH**/ ?>