
<?php $__env->startSection('contenido'); ?>
    <h2>Inicio de administrador</h2>
    <img class="text-center" src="<?php echo e(asset('imagenes/admin-img.jpg')); ?>" height="80%" width="90%" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/perfil.blade.php ENDPATH**/ ?>