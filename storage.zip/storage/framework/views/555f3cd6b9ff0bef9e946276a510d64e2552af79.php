
<?php $__env->startSection('contenido'); ?>
    <h2>Visualización de cursos</h2>
    <form action="<?php echo e(route('curso.index')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" value="<?php echo e($curso->nombre); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="lugar">Lugar</label>
            <input type="text" name="lugar" value="<?php echo e($curso->lugar); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="tiempo">Tiempo</label>
            <input type="text" name="tiempo" value="<?php echo e($curso->tiempo); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="fechacomienzo">Fecha Comienzo</label>
            <input type="date" name="fechacomienzo" value="<?php echo e($curso->fechaComienzo); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="fechafin">Fecha Fin</label>
            <input type="date" name="fechafin" value="<?php echo e($curso->fechaFin); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="modalidad">Modalidad</label>
            <input type="text" name="modalidad" value="<?php echo e($curso->modalidad); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="firma">Firma</label>
            <input type="text" name="firma" value="<?php echo e($curso->firma); ?>" class="form-control" readonly />
        </div>
        <div>
            <label for="archivo">Archivo</label>
            <input type="file" name="archivo" value="<?php echo e($curso->archivo); ?>" class="form-control" readonly />
        </div>
        <input class="btn btn-success mt-2 form-control" type="submit" value="Regresar"/>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/curso/show.blade.php ENDPATH**/ ?>