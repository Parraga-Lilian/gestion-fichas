
<?php $__env->startSection('contenido'); ?>
<h2>Editar datos de Empleado</h2>
<form action="<?php echo e(route('empleadoi.update', $empleadoi)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div>
        <label for="cedula">Cedula</label>
        <input type="number" name="cedula" class="form-control" value="<?php echo e($empleadoi->cedula); ?>">
    </div>
    <div>
        <label for="nombres">Nombres</label>
        <input type="text" name="nombres" class="form-control" value="<?php echo e($empleadoi->nombres); ?>" />
    </div>
    <div>
        <label for="apellidos">Apellidos</label>
        <input type="text" name="apellidos" class="form-control" value="<?php echo e($empleadoi->apellidos); ?>" />
    </div>
    <div>
        <label for="direccion">Direccion</label>
        <input type="text" name="direccion" class="form-control" value="<?php echo e($empleadoi->direccion); ?>" />
    </div>
    <div>
        <label for="telefono">Telefono</label>
        <input type="text" name="telefono" class="form-control" value="<?php echo e($empleadoi->telefono); ?>" />
    </div>
    <div>
        <label for="cargo">Cargo</label>
        <select class="form-select" aria-label="Default select example" name="cargo">
            <?php $__currentLoopData = array("Funcionario","Vendedor","Asistente","Logística",
            "Supervisor","Recursos Humanos","Otros"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cargo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cargo == $empleadoi->cargo): ?>
                    <option value="<?php echo e($cargo); ?>" selected><?php echo e($cargo); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($cargo); ?>"><?php echo e($cargo); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label for="horario">Horario</label>
        <select class="form-select" aria-label="Default select example" name="horario">
            <?php $__currentLoopData = array("4-10 a.m.","8-12 a.m.","2-5 p.m.","5-9 p.m.","9 p.m.-12 a.m."); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($horario == $empleadoi->horario): ?>
                    <option value="<?php echo e($horario); ?>" selected><?php echo e($horario); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($horario); ?>"><?php echo e($horario); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label for="seccion">Seccion</label>
        <select class="form-select" aria-label="Default select example" name="seccion">
            <?php $__currentLoopData = array("Matutina","Vespertina","Nocturna","Jornada completa","Medio tiempo","Otros"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($seccion == $empleadoi->seccion): ?>
                    <option value="<?php echo e($seccion); ?>" selected><?php echo e($seccion); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($seccion); ?>"><?php echo e($seccion); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label for="estado">Estado</label>
        <select class="form-select" aria-label="Default select example" name="estado">
            <?php $__currentLoopData = array("activo","en proceso","desactivado"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($estado == $empleadoi->estado): ?>
                    <option value="<?php echo e($estado); ?>" selected><?php echo e($estado); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($estado); ?>"><?php echo e($estado); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div>
        <label for="Foto">Foto</label>
        <img id="imgId" src="<?php echo e(asset('storage').'/'.$empleadoi->Foto); ?>" width="100px" alt="" />
        <input class="form-control" type="file" name="Foto" onchange="read(this)" />
    </div>
    <div>
        <input class="btn btn-success mt-2 form-control" type="submit" value="Modificar"/>
        <a class="btn btn-warning mt-1 form-control" href="<?php echo e(route('empleadoi.index', $empleadoi)); ?>">Regresar</a>
    </div>
</form>
<script>
    function read(val) {
        const reader = new FileReader();
        reader.onload = (event) => {
            document.getElementById("imgId").src = event.target.result;
        }
        reader.readAsDataURL(val.files[0]);
    }
</script>
<?php echo $__env->make('layouts.generaldialog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('okEmployeeEdit'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/empleadoi/edit.blade.php ENDPATH**/ ?>