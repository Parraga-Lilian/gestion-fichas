
<?php $__env->startSection('contenido'); ?>
<h1>Perfil de administrador</h1>
    <?php if(auth()->guard()->check()): ?>
      <?php if(is_null($administrador)): ?>
        <strong>No has ingresado. </strong>
        <a href="/logout">Login</a> 
      <?php else: ?>
          <section style="background-color: #eee;">
            <div class="container py-5">
              <div class="row">
                <div class="col-lg-4">
                  <div class="card mb-4">
                    <div class="card-body text-center">
                      <?php if(empty($administrador->Foto)): ?>
                          <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp" 
                          alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">
                        <?php else: ?>
                          <img src="<?php echo e(asset('storage').'/'.$administrador->Foto); ?>" alt="avatar" 
                          class="rounded-circle img-fluid" style="width: 150px;">
                        <?php endif; ?>
                      <h5 class="my-3"><?php echo e(auth()->user()->username ?? auth()->user()->name); ?></h5>
                      <p class="text-muted mb-1">Cédula: <?php echo e($administrador->cedula ?? ""); ?></p>
                      <p class="text-muted mb-2">F. Ingreso: <?php echo e(auth()->user()->created_at->toDateString() ?? ""); ?></p>
                      <p class="text-muted mb-2">Actualizado: <?php echo e(auth()->user()->updated_at->toDateString() ?? ""); ?></p>
                      <div class="d-flex justify-content-center mb-2">
                        <a type="button" class="btn btn-primary" class="btn btn-warning" 
                        href="<?php echo e(route('administrador.edit',$administrador->idAdministrador)); ?>">Editar perfil</a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-8">
                  <div class="card mb-4">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-sm-3">
                          <p class="mb-0">Nombres:</p>
                        </div>
                        <div class="col-sm-9">
                          <p class="text-muted mb-0"><?php echo e($administrador->nombres . ' ' . $administrador->apellidos); ?></p>
                        </div>
                      </div>
                      <hr>
                      <div class="row">
                        <div class="col-sm-3">
                          <p class="mb-0">Email: </p>
                        </div>
                        <div class="col-sm-9">
                          <p class="text-muted mb-0"><?php echo e(auth()->user()->email ?? ""); ?></p>
                        </div>
                      </div>
                      <hr>
                      <div class="row">
                        <div class="col-sm-3">
                          <p class="mb-0">Direccion: </p>
                        </div>
                        <div class="col-sm-9">
                          <p class="text-muted mb-0"><?php echo e($administrador->direccion ?? ""); ?></p>
                        </div>
                      </div>
                      
                      <hr>
                      <div class="row">
                        <div class="col-sm-3">
                          <p class="mb-0">Telefono: </p>
                        </div>
                        <div class="col-sm-9">
                          <p class="text-muted mb-0">(+593) <?php echo e($administrador->telefono ?? ""); ?></p>
                        </div>
                      </div>
                      <hr>
                      <div class="row">
                        <div class="col-sm-3">
                          <p class="mb-0">Especialidad: </p>
                        </div>
                        <div class="col-sm-9">
                          <p class="text-muted mb-0"><?php echo e($administrador->especialidad ?? ""); ?></p>
                        </div>
                      </div>
                     
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>  
      <?php endif; ?>
    <?php endif; ?>
<script>
    const list = document.getElementsByTagName("LI")[0];
    list.className += "active";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\login-laravel-main\resources\views/administrador/index.blade.php ENDPATH**/ ?>